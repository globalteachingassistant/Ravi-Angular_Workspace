import { Input, Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appComplete]'
})
export class CompleteDirective {
  @Input('appComplete') completed:boolean;

  constructor(private el: ElementRef) { }

  ngOnInit() {
      if(this.completed) {
        this.el.nativeElement.style.textDecoration = 'line-through'
      }
  } 
}
