import { Component, OnInit } from '@angular/core';
import { TaskService } from 'src/app/services/task.service';
import { Task } from 'src/app/models/task';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent implements OnInit {
  
  tasks: Task[] = []; 
  msg: string = ''
  
  constructor(private taskService: TaskService) { }

  ngOnInit() {
      this.getTasks();
  }
  
  getTasks() {
      this.taskService.getTasks().subscribe((data: Task[]) => {
          this.tasks = data
      })
  }
  
  removeTask(id) {
    this.taskService.removeTask(id).subscribe(() => {
        this.msg = 'Task Removed!'
        setTimeout(() => this.msg = '', 3000)
        this.getTasks();
    })
  }

}
