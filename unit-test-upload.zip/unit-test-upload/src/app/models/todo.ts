export class Todo {
  userId: number;
  id: number;
  title: string;
  completed: boolean;

  constructor(id, userId, title, completed = false) {
    this.id = id;
    this.userId = userId;
    this.title = title;
    this.completed = completed;
  }
}
