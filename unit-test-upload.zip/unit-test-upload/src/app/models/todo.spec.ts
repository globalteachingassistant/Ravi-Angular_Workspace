import { Todo } from './todo';

describe('Todo', () => {
  it('should create an instance', () => {
    expect(new Todo(1, 1, 'Test')).toBeTruthy();
  });

  it('should have completed to be false by default', () => {
    const todo = new Todo(1, 1, 'TEST')
    expect(todo.completed).toBe(false)
  })
});
