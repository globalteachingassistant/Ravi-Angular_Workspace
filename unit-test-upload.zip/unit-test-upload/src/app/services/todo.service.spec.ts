import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing'
import { TestBed } from '@angular/core/testing';

import { TodoService } from './todo.service';

describe('TodoService', () => {
  let service: TodoService = null;
  let httpTest: HttpTestingController = null;

  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [TodoService]
  }));

  beforeEach(() => {
    service = TestBed.get(TodoService);
    httpTest = TestBed.get(HttpTestingController);
  })

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return a set of Todos on calling getTodos', () => {
    const dummyData1 = [
      { id: 1, userId: 1, title: 'TEST', completed: true },
      { id: 1, userId: 1, title: 'TEST', completed: true }
    ]

    const dummyData2 = [
      { id: 1, userId: 1, title: 'TEST', completed: true },
      { id: 1, userId: 1, title: 'TEST', completed: true }
    ]

    service.getTodos().subscribe(data => {
      expect(data).toEqual(dummyData1);
    })

    const req = httpTest.expectOne(service.apiUrl, 'Call to an api')
    req.flush(dummyData2)

    httpTest.verify()
  })
});
