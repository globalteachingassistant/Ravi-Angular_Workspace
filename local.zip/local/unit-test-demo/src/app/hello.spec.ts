function add(a = 0, b = 0) {
  return a + b
}

describe('Aritmetic', () => {
  it('Adds two numbers correctly', () => {
    expect(add(10, 20)).toBe(30)
  })

  it('Returns zero when no args passed', () => {
    expect(add()).toBe(0)
  })
})
